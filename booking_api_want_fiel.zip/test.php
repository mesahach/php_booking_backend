<?php
$secret = base64_encode(random_bytes(64));
echo $secret;