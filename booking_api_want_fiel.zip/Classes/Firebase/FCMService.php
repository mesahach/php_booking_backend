<?php
namespace MyApp\Firebase;

use Exception;
use Google\Auth\Credentials\ServiceAccountCredentials;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;

class FCMService
{
    private string $projectId;
    private string $serviceAccountPath;
    private Client $httpClient;

    public function __construct()
    {
        $this->projectId = $_ENV['FIREBASE_PROJECT_ID'];
        
        $serviceAccountPath = __DIR__ . '/mtech-livechat-86008ed84c.json';
        $this->serviceAccountPath = $serviceAccountPath;
        $this->httpClient = new Client();
    }

    private function getAccessToken(): string
    {
        $scopes = ['https://www.googleapis.com/auth/firebase.messaging'];

        $creds = new ServiceAccountCredentials($scopes, $this->serviceAccountPath);
        $token = $creds->fetchAuthToken();

        if (!isset($token['access_token'])) {
            throw new Exception("Failed to get access token");
        }

        return $token['access_token'];
    }

    public function sendPushNotification(string $deviceToken, string $title, string $body, array $data = []): bool
    {
        if (empty($deviceToken)) {
            return false;
        }

        // ✅ Force $extraData to be an object/map
        if (empty($data)) {
            $data = new \stdClass(); // send as {}
        }

        $accessToken = $this->getAccessToken();

        $url = "https://fcm.googleapis.com/v1/projects/{$this->projectId}/messages:send";

        $message = [
            'message' => [
                'token' => $deviceToken,
                'notification' => [
                    'title' => $title,
                    'body' => $body,
                ],
                'data' => $data
            ]
        ];

        try {
            $response = $this->httpClient->post($url, [
                'headers' => [
                    'Authorization' => "Bearer {$accessToken}",
                    'Content-Type' => 'application/json',
                ],
                'json' => $message
            ]);

            if ($response->getStatusCode() === 200) {
                return true;
            }
            return false;

        } catch (RequestException $e) {
            // $responseBody = $e->getResponse()?->getBody()?->getContents();
            // echo $responseBody;
            return false;
        }
    }
}