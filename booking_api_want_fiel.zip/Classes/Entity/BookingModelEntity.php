<?php 
namespace MyApp\Entity;

use DateTimeImmutable;

class BookingModelEntity
{
    private ?string $uuid;
    private ?string $celebrityUuid;
    private ?DateTimeImmutable $bookingDate;
    private ?DateTimeImmutable $bookingTime;
    private ?string $bookingStatus;
    private ?string $createdAt;
    private ?string $updatedAt;

    public function setUuid(string $uuid): self
    {
        $this->uuid = $uuid;
        return $this;
    }

    public function getUuid(): ?string
    {
        return $this->uuid;
    }

    public function setCelebrityUuid(string $uuid): self
    {
        $this->celebrityUuid = $uuid;
        return $this;
    }

    public function getCelebrityUuid(): ?string
    {
        return $this->celebrityUuid;
    }

    public function setBookingDate(?string $date): self
    {
        $this->bookingDate = $date ? DateTimeImmutable::createFromFormat('Y-m-d', $date) : null;
        return $this;
    }

    public function getBookingDate(): ?DateTimeImmutable
    {
        return $this->bookingDate;
    }

    public function setBookingTime(?string $time): self
    {
        $this->bookingTime = $time ? DateTimeImmutable::createFromFormat('H:i:s', $time) : null;
        return $this;
    }

    public function getBookingTime(): ?DateTimeImmutable
    {
        return $this->bookingTime;
    }

    public function setBookingStatus(string $bookingStatus): self
    {
        $this->bookingStatus = $bookingStatus;
        return $this;
    }

    public function getBookingStatus(): ?string
    {
        return $this->bookingStatus;
    }

    public function setCreatedAt(string $createdAt): self
    {
        $this->createdAt = $createdAt;
        return $this;
    }

    public function getCreatedAt(): ?string
    {
        return $this->createdAt;
    }

    public function setUpdatedAt(string $updatedAt): self
    {
        $this->updatedAt = $updatedAt;
        return $this;
    }

    public function getUpdatedAt(): ?string
    {
        return $this->updatedAt;
    }

    public function __toArray(): array
    {
        return [
            'uuid' => $this->uuid,
            'celebrityUuid' => $this->celebrityUuid,
            'bookingDate' => $this->bookingDate,
            'bookingTime' => $this->bookingTime,
            'bookingStatus' => $this->bookingStatus,
            'createdAt' => $this->createdAt,
            'updatedAt' => $this->updatedAt,
        ];
    }

    public function __fromArray(array $data): self
    {
        $this->uuid = $data['uuid'];
        $this->celebrityUuid = $data['celebrityUuid'];
        $this->bookingDate = $data['bookingDate'];
        $this->bookingTime = $data['bookingTime'];
        $this->bookingStatus = $data['bookingStatus'];
        $this->createdAt = $data['createdAt'];
        $this->updatedAt = $data['updatedAt'];
        return $this;
    }
}