<?php
namespace MyApp\Controllers;

use MyApp\Models\BookingModel;
use MyApp\Utils\ValidatorHelper as v;
use PH7\JustHttp\StatusCode;

class BookingController extends FunctionsController
{
    protected BookingModel $model;
    private const DATE_TIME_FORMAT = 'Y-m-d H:i:s';

    public function __construct()
    {
        $this->model = new BookingModel();
    }

    public function create(array $data)
    {
        $requiredInputs = [
            'uuid',
            'booking_date',
            'booking_time',
        ];
        $this->validateParams($data, $requiredInputs);

        $validators = [
            v::validateUuid($data['uuid']),
            v::validateDate($data['booking_date'], 'Booking Date'),
            v::validateTime($data['booking_time'], 'Booking Time'),
        ];
        $this->validateInputs($validators);

        return $this->model->create($data);
    }

}