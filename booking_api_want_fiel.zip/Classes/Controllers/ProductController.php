<?php 
namespace MyApp\Controllers;

use MyApp\Controllers\FunctionsController;

class ProductController extends FunctionsController {
    
}
