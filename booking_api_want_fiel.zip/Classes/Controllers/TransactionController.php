<?php 
namespace MyApp\Controllers;

use MyApp\Controllers\FunctionsController;

class TransactionController extends FunctionsController {
    
}
