<?php
namespace MyApp\Models;

use Ramsey\Uuid\Uuid;
use MyApp\Entity\BookingModelEntity;
use MyApp\DAL\BookingDal;
use PH7\JustHttp\StatusCode;
use Exception;
use PH7\PhpHttpResponseHeader\Http;
use MyApp\Validation\Exception\InvalidUserException;
use DateTimeImmutable;

class BookingModel
{
    public const DATE_TIME_FORMAT = 'Y-m-d H:i:s';
    private readonly string $userUuid;

    public function create(array $data)
    {
        $uuid = Uuid::uuid4();
        $bookingModel = new BookingModelEntity();
        $bookingModel->setUuid($uuid)
            ->setCelebrityUuid($data['uuid'])
            ->setBookingDate($data['booking_date'])
            ->setBookingTime($data['booking_time'])
            ->setBookingStatus($data['booking_status'])
            ->setCreatedAt(date(self::DATE_TIME_FORMAT))
            ->setUpdatedAt(date(self::DATE_TIME_FORMAT));

        try {
            $bookingDal = new BookingDal();
            $bookingDal->create($bookingModel);
            return ['status' => true, 'message' => 'Booking created', 'data' => $bookingModel->__toArray(), 'code' => StatusCode::CREATED];
        } catch (Exception $e) {
            return ['status' => false, 'message' => $e->getMessage(), 'code' => StatusCode::EXPECTATION_FAILED];
        }
    }

    public function get(int|string $uuid): BookingModelEntity|null
    {
        try {
            $booking = BookingDal::get($uuid);
            if (!$booking) {
                return null;
            }

            return $booking;
        } catch (Exception $e) {
            return null;
        }
    }

    public function getAll(): array
    {
        $bookings = BookingDal::getAll();
        return $bookings;
    }

    public function update(int|string $uuid, array $data): bool
    {
        try {
            $booking = BookingDal::get($uuid);
            if (!$booking) {
                return false;
            }

            $booking->setBookingDate($data['booking_date'])
                ->setBookingTime($data['booking_time'])
                ->setBookingStatus($data['booking_status'])
                ->setUpdatedAt(date(self::DATE_TIME_FORMAT));

            BookingDal::update($uuid, $booking);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    public function delete(int|string $uuid): bool
    {
        try {
            $booking = new BookingDal();
            $result = $booking->delete($uuid);
            return $result;
        } catch (Exception $e) {
            return false;
        }
    }
}