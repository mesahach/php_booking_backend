<?php 
namespace MyApp\Models;

class ProductModel {
    
}