<?php
namespace MyApp\Config;

use MyApp\Config\DatabaseConfig;

// SET RedBean DB
// i installed chocolaty
// i installed mysql

DatabaseConfig::init();
