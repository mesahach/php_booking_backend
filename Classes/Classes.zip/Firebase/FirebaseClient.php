<?php
namespace MyApp\Firebase;

use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;

class FirebaseClient
{
    private $firestore;

    public function __construct()
    {
        $serviceAccountPath = __DIR__ . '/mtech-livechat-86008ed84c.json';

        $factory = (new Factory)
            ->withServiceAccount($serviceAccountPath);

        $this->firestore = $factory->createFirestore()->database();
    }

    public function getFirestore()
    {
        return $this->firestore;
    }
}
